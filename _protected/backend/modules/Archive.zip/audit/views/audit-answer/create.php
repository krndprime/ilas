<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model backend\modules\audit\models\AuditAnswer */

?>
<div class="audit-answer-create">
    <?= $this->render('_form_2', [
        'model' => $model,
    ]) ?>
</div>
