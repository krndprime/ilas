<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model backend\modules\audit\models\AuditAnswer */
?>
<div class="audit-answer-update">

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
