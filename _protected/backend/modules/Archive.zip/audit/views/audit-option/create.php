<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model backend\modules\audit\models\AuditOption */

?>
<div class="audit-option-create">
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
</div>
