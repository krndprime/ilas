<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model backend\modules\inspection\models\InspectionAnswer */

?>
<div class="inspection-answer-create">
    <?= $this->render('_form_2', [
        'model' => $model,
    ]) ?>
</div>
