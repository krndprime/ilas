<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model backend\modules\inspection\models\InspectionAnswer */
?>
<div class="inspection-answer-update">

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
