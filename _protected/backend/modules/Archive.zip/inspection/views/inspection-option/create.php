<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model backend\modules\inspection\models\InspectionOption */

?>
<div class="inspection-option-create">
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
</div>
