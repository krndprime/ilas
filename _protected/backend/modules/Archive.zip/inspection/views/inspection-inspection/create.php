<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model backend\modules\inspection\models\InspectionInspection */

?>
<div class="inspection-inspection-create">
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
</div>
