<?php

use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model backend\modules\inspection\models\InspectionInspection */
?>
<div class="inspection-inspection-view">
 
    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            //'id',
            'name',
            'year',
            //'month',
            [
                'attribute'=>'month',
                'format' => 'raw',
                'value' => function ($data){
                        return date('F', mktime(0, 0, 0,$data['month'], 10));
                },
            ],
            //'created_by',
            //'created_on',
            //'status',
        ],
    ]) ?>

</div>
