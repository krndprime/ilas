<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model backend\modules\inspection\models\InspectionInspection */
?>
<div class="inspection-inspection-update">

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
