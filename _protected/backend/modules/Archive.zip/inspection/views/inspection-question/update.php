<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model backend\modules\inspection\models\InspectionQuestion */
?>
<div class="inspection-question-update">

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
