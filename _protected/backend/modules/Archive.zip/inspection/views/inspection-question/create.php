<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model backend\modules\inspection\models\InspectionQuestion */

?>
<div class="inspection-question-create">
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
</div>
